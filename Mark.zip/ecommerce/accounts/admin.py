from django.contrib import admin

from .models import GuestEmail

admin.site.register(GuestEmail)